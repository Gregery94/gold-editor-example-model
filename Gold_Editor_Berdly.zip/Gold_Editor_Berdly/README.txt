This FBX file was created by halofactory. please credit if used.
twitter:
twitter.com/halofactorymoon

--- this folder was created to assist with new SSB64 modders with model importing with the Gold Editor https://github.com/carnivoroussociety/GoldEditor --

steps:
- open model editor
- select your ROM
- choose Fox's model
- *optional* click disable low res model. wait for it to calculate
- click "import and add textures"
- select textures.txt when prompted
- select the berdly fbx when prompted
- select special texture mapping when prompted
- you may select recalculate normals
- when done, write the rom and play the game.
- you just imported a model into ssb64!